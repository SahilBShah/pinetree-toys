proteomics_rna_simulation.Rmd - analysis of protein/transcript relationship in simulation
simulation.Rmd - old simulation analyses
proteomics.Rmd - proteomics analyses and plots
rnaseq.Rmd - RNA sequencing analyses and plots
