data/ - all raw data
analysis/ - proteomics, rna-seq, and simulation analyses and plots
src/ - R and python scripts for data pre-processing
output/ - Intermediate outputs such as pre-processed data that are ready for analysis in Rmarkdown
