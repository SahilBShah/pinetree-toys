pinetree_run.py ./T7_012418_wt.yml -o ./run_T7_012418_wt
pinetree_run.py ./T7_012418b_wt.yml -o ./run_T7_012418b_wt
