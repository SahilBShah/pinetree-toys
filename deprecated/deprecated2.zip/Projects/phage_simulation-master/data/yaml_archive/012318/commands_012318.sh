pinetree_run.py ./T7_012318_wt.yml -o ./run_T7_012318_wt
pinetree_run.py ./T7_012318b_wt.yml -o ./run_T7_012318b_wt
