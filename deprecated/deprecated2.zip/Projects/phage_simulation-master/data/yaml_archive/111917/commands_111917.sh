pinetree_run.py ./T7_111917_w1_phi9.yml -o ./run_T7_111917_w1_phi9
pinetree_run.py ./T7_111917_w1_phi9_10.yml -o ./run_T7_111917_w1_phi9_10
pinetree_run.py ./T7_111917_w1_phi10.yml -o ./run_T7_111917_w1_phi10
